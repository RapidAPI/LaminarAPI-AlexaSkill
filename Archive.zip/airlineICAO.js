const ICAO = {
  "Southwest": "SWA",
  "American": "AAL",
  "United": "UAL",
  "Alitalia": "SMX",
  "British": "BAW",
  "Qatar": "QTR",
  "Emirates": "UAE",
  "Etihad": "ETD",
  "Delta": "DAL",
  "Spirit": "NKS"
};

module.exports = ICAO;
