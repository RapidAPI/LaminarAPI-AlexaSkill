const IATA = {
  "Emirates": "EK",
  "Southwest": "WN",
  "American": "AA",
  "United": "UA",
  "Alitalia": "AZ",
  "British": "BA",
  "Qatar": "QR",
  "Etihad": "EY",
  "Delta": "DL",
  "Spirit": "NK"
};

module.exports = IATA;
